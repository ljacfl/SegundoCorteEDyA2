import './App.css'
import { AddCategory } from './components/AddCategory'

function App() {  
  return (
    <>
      <h1>Hola Mundo! </h1>
      <h2> Bienvenido </h2>
      
    </>
  )
}

export default App
